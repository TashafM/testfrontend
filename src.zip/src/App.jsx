
const App = () => {
  return (
    <div className="app">
      <h1>All Users Data</h1>
      <button>Fetch Data</button>
    </div>
  )
}

export default App
